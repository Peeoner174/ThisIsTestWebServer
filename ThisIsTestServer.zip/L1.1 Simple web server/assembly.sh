mvn compile assembly:single
