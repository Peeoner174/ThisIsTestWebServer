package com.example.foo.Note.note;
//DAO компонент
//Основная задача состоит в том, что бы взять объекты и "превратить" их в запрос к БД либо предоставить разработчику
// функции при вызове которой внутри себя DAO создаст запрос к БД, а разработчику отдаст объекты. DataSet - Data Set - набор данных.
import com.example.foo.Note.note.Note;
import org.springframework.data.repository.CrudRepository;

public interface RepositoryNote extends CrudRepository<Note, String> {
}
