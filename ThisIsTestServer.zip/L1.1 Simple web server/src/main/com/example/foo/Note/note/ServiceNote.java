package com.example.foo.Note.note;
//Бизнес-логика
import org.springframework.stereotype.Service;

@Service
public class ServiceNote {
    ServiceNote(RepositoryNote repositoryNote){this.repositoryNote = repositoryNote;}
   private RepositoryNote repositoryNote;

    public RepositoryNote getRepositoryNote() {
        return repositoryNote;
    }

    public void setRepositoryNote(RepositoryNote repositoryNote) {
        this.repositoryNote = repositoryNote;
    }

    Note add(Note note){return repositoryNote.save(note);}
    Note get(String id){return repositoryNote.findOne(id);}
    void remove(String id){ repositoryNote.delete(id);}
    Note edit(String id, Note note){return repositoryNote.save(note.copy(id));}
    Iterable <Note> all(){return repositoryNote.findAll();}

}







