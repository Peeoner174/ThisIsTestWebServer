package com.example.foo.Note.note;

//Отвечает за создание таблицы из объектов класса, конвертация таблицы в JSON
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.GenericGenerator;
import java.util.*;
import javax.persistence.*;

@Entity  //объект класса можно переложить в таблицу
@Table(name = "notes") //связывает класс и таблицу
public class Note{
        public Note(String id, String title, String text, Long date_create, Long date_update) {
                this.id = id;
                this.title = title;
                this.text = text;
                this.date_create = date_create;
                this.date_update = date_update;
        }

        @Override
        public String toString() {
                return "Note1{" +
                        "id='" + id + '\'' +
                        ", title='" + title + '\'' +
                        ", text='" + text + '\'' +
                        ", date_create=" + date_create +
                        ", date_update=" + date_update +
                        '}';
        }

        @Override
        public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;

                Note note = (Note) o;

                if (!id.equals(note.id)) return false;
                if (!title.equals(note.title)) return false;
                if (!text.equals(note.text)) return false;
                if (!date_create.equals(note.date_create)) return false;
                return date_update.equals(note.date_update);
        }

        @Override
        public int hashCode() {
                int result = id.hashCode();
                result = 31 * result + title.hashCode();
                result = 31 * result + text.hashCode();
                result = 31 * result + date_create.hashCode();
                result = 31 * result + date_update.hashCode();
                return result;
        }


        @PrePersist
        private void onCreate() {
                Date date=new Date();
                date_create = date.getTime();
                date_update = date_create;
        }

        public String getId() {
                return id;
        }

        public void setId(String id) {
                this.id = id;
        }

        public String getTitle() {
                return title;
        }

        public void setTitle(String title) {
                this.title = title;
        }

        public String getText() {
                return text;
        }

        public void setText(String text) {
                this.text = text;
        }

        public Long getDate_create() {
                return date_create;
        }

        public void setDate_create(Long date_create) {
                this.date_create = date_create;
        }

        public Long getDate_update() {
                return date_update;
        }

        public void setDate_update(Long date_update) {
                this.date_update = date_update;
        }

        public Note(String id) {

                this.id = id;
        }

        public Note() {

        }

        @Id// поле является первичным ключом в таблице
        @JsonProperty("id") //данный атрибут в JSON будет именоваться как "id"
        @Column(name = "id", nullable = false)//связывает поле и колонку в таблице
        @GeneratedValue(strategy = GenerationType.AUTO, generator = "uuid")//определяет стратегию создания первичного ключа
        @GenericGenerator(name = "uuid", strategy = "uuid2")//Позволяет определить специфичный id генератор
        String id=null;


        @JsonProperty("title")  @Column(name = "title", length = 30)    String title = "";

        @JsonProperty("text")   @Column(name = "text", length = 500)    String text = "";

        @JsonProperty("date_create")    @Column(name = "date_create", updatable = false)
        Long date_create = 0L;

        @JsonProperty("date_update")    @Column(name = "date_update")   Long date_update = 0L;



@PreUpdate
private void onUpdate() {
        Date date=new Date();
        date_update = date.getTime();
        }

        public Note copy(String id){Note.this.id=id; return this;}



        }



