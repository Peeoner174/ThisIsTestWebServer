package com.example.foo.Note.note;

//Данный класс представляет собой компонент, похожий на обычный сервлет (HttpServlet) (работающий с объектами
// HttpServletRequest и HttpServletResponse), но с расширенными возможностями от Spring Framework.
//может возвращать кастомный объект в виде xml, json
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class ControllerNote {
    ControllerNote(ServiceNote serviceNote){this.serviceNote = serviceNote;}
    private ServiceNote serviceNote;


    @GetMapping
    Iterable <Note> index(){return serviceNote.all();}

    public ServiceNote getServiceNote() {
        return serviceNote;
    }

    public void setServiceNote(ServiceNote serviceNote) {
        this.serviceNote = serviceNote;
    }

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.FOUND)
    Note read(@PathVariable String id){return serviceNote.get(id);}

    @DeleteMapping("{id}")
    void delete(@PathVariable String id){ serviceNote.remove(id);}

    @PutMapping("{id}")
    Note update(@PathVariable String id,@RequestBody Note note){return serviceNote.edit(id, note);}

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    Note create(@RequestBody Note note){return serviceNote.add(note);}

}

